#include "test.h"

int main()
{
	print_arch();
}
