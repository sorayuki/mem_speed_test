void print_arch();
